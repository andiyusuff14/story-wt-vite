class PushView {
  static renderButton() {
    return `
        <button id="subscribe-btn">Aktifkan Notifikasi</button>
      `;
  }
}

export default PushView;
